import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-hp',
  templateUrl: './hp.component.html',
  styleUrls: ['./hp.component.scss']
})
export class HpComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
